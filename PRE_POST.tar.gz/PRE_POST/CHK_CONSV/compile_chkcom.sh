#!/bin/csh
setenv LANG C
#
set FORTRAN = frt
set DEBUG=''
set OPTION=' -O2'
set SRCNAME1=chk-consv5.f90
set LIBNAME=' -lGSPS -L/home/satake/GSPS/GSPS-V4.3.1/lib'
set EXECNAME=gochk-consv5
#
#  Compile
#

${FORTRAN}  ${DEBUG}     ${OPTION}  \
         -o ${EXECNAME} ${SRCNAME1} ${LIBNAME}


