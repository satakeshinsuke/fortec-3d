#!/bin/csh
#
setenv LANG C
#
#
set EXECNAME=/data/lng/satake/FORTEC-3D_v3-3_final/PRE_POST/CHK_CONSV/gochk-consv5

set DATDIR=/data/lng/satake/FORTEC-3D_v3-3_final/SAMPLE/ion-1st+-00_plot

set GRPDIR=${DATDIR}/Graph

set ID=""

cd  ${DATDIR}
if(! -d ${GRPDIR}) then
mkdir ${GRPDIR}
endif

#convert endian (running on vis1)
setenv FORT90L -Wl,-T

# input files
setenv fu20 ${DATDIR}/out0.22
setenv fu21 ${DATDIR}/out1.22
setenv fu22 ${DATDIR}/out2.22
setenv fu23 ${DATDIR}/out3.22
setenv fu24 ${DATDIR}/out4.22
setenv fu25 ${DATDIR}/out5.22
setenv fu26 ${DATDIR}/out6.22
setenv fu27 ${DATDIR}/out7.22
setenv fu28 ${DATDIR}/out8.22
setenv fu29 ${DATDIR}/out9.22
setenv fu30 ${DATDIR}/out10.22

setenv fu93 ${DATDIR}/out.13
setenv fu98 ${DATDIR}/out8.98


# output file
setenv fu10 ${GRPDIR}/log-chkcom${ID}
setenv fu11 ${GRPDIR}/dspctl${ID}.dat
#setenv fu11 /dev/null
setenv fu12 ${GRPDIR}/bad-col${ID}.dat
setenv fu18 ${GRPDIR}/consv${ID}.ps
setenv fu40 ${GRPDIR}/chkdiff${ID}.dat
#setenv fu40 /dev/null
setenv fu41 ${GRPDIR}/log-dmom${ID}.dat
setenv fu42 ${GRPDIR}/log-dmom_av${ID}.dat
setenv fu51 ${GRPDIR}/dn-spctl${ID}.dat
setenv fu53 ${GRPDIR}/dn-prof${ID}.dat
setenv fu54 ${GRPDIR}/upl-prof${ID}.dat

# note: if (npr,npa,npz==0) then all cell data on each dimension are plotted
${EXECNAME}  << @namelist
 &indata1
	ngost=8,
        ngoed=8,
        npa=5,
        npr=6,
        npz=3,
        ndivz=5,
	lfixnt=.true.,
	llocal=.false.,
 &end
 &indata2
        ipa(1) =  1,
	ipa(2) =  4,
	ipa(3) =  9,
	ipa(4) = 13,
	ipa(5) = 17,
	ipr(1) =  1,
	ipr(2) = 10,
	ipr(3) = 20,
	ipr(4) = 30,
	ipr(5) = 40,
	ipr(6) = 50,
	ipz(1) =  1,
	ipz(2) =  3,
	ipz(3) =  5,
  &end
  &indata3
	lupl=.false.,
        ldmode=.true.,
        mmin=-3,
	mmax=3,
	nmin=0,
	nmax=3,
  &end
@namelist
#
gzip -f ${fu18}

exit

