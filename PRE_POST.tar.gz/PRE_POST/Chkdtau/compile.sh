#!/bin/csh

set WORKDIR=tmpcomp
#
set FORTRAN = frtpx
set DEBUG=''
set OPTION='-Kfast -Qt'

set SRCNAME1=dtauchk-v33.f90
#set SRCNAME1=dtauchk-lof3d.f90

set EXECNAME=gochkdtau-v33
#set EXECNAME=gochkdtau-lof3d

set SRC1=./${SRCNAME1}
set EXEC=./${EXECNAME}
#
#  Compile
#
${FORTRAN}  ${DEBUG} ${OPTION} -o ${EXECNAME} ${SRCNAME1} 

