#! /bin/csh
#
#PJM -L "rscunit=fx"
#PJM -L "rscgrp=small"
#PJM -L "node=1"
#PJM -L "elapse=0:01:00"
#PJM -j 
#PJM -g 18243

set NAME=136335t4970_D

# in this example, electron and ion can be switched by the variable "ID=_e (or _i)"
set ID="_e"

set DIR=/data/lng/satake/FORTEC-3D_v3-3_final/PRE_POST/Chkdtau/Sample
set EXEC=/data/lng/satake/FORTEC-3D_v3-3_final/PRE_POST/Chkdtau/gochkdtau-v33

cd ${DIR}

#input files
setenv fu07 input-f3d-v3-3_lhd${ID}.dat
setenv fu18 field-data.${NAME}
#output files
setenv fu12 chkdtau${ID}.out
setenv fu13 chkcoll${ID}.out


setenv FORT90L -Wl,-T18

${EXEC}  << @namelist

 &spec
ihm   = 2,
ihn   = 10,
 &end
@namelist


