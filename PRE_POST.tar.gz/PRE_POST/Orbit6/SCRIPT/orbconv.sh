#!/bin/csh -f

#PJM -L "rscunit=fx"
#PJM -L "rscgrp=small"
#PJM -L "node=1"
#PJM -L "elapse=0:15:00"
#PJM -j
#PJM -g 18243

setenv PARALLEL 16
setenv OMP_NUM_THREADS 16

set NAME=126515t3740_H

set DATDIR=/data/lng/satake/FORTEC-3D_v3-3_final/SAMPLE/ion-1st+-00_orbit

## ! binary data in little endian
setenv FORT90L -Wl,-T23

set EXECDIR=/data/lng/satake/FORTEC-3D_v3-3_final/PRE_POST/Orbit6
set EXECNAME=goorb6.go

cp -f ${EXECDIR}/${EXECNAME} ${DATDIR}
cd  ${DATDIR}

# input files
setenv fu07 ${DATDIR}/out0.07
setenv fu23 ${DATDIR}/../EQUIL/xspctl.${NAME}

# output files
setenv fu15 orbdata_${NAME}.txt
setenv fu16 chklog_${NAME}.txt
setenv fu17 chkelfd_${NAME}.txt

#execution

${DATDIR}/${EXECNAME} << @namelist 
&ptin
    nskip=5,
    nnode=8,
    ngo=0,
    mmxcut=39,
    mmxcut_as=0,
    ndivz=5,
    lasym=.false.,
    lerfld=.true.,
&end
@namelist
#
#   nskip : interval of orbit plotting 
#   nnode : number of "orb_000_xxxx" files to read
#   ngo   : number of job indicator "orb_yyy_****"
#   mmxcut : number of Fourier spectrum to convert (rho,theta,zeta) to (R,phi,Z) 
#   mmxcut_as :  for u-d asym. part 
#   ndivz : toroidal period  (in out*.06)
#   lasym : up-down symmetry or not
#   lerfld : energy convergence check with E_r
#

# atokataduke
rm -f ${DATDIR}/${EXECNAME}





