#!/bin/csh -f
#PJM -L "rscunit=fx"
#PJM -L "rscgrp=small"
#PJM -L "node=1"
#PJM -L "elapse=0:15:00"
#PJM -j
#PJM -g 18243

setenv PARALLEL 16
setenv OMP_NUM_THREADS 16

set EXECNAME=/data/lng/satake/FORTEC-3D_v3-3_final/PRE_POST/NEWHATTEN/gohatten-13b

##### loop start #####
foreach DIRL( ion-1st+-00)
set DATDIR=/data/lng/satake/FORTEC-3D_v3-3_final/SAMPLE/${DIRL}
#####


set GRPDIR=${DATDIR}/Graph_hat

cd ${DATDIR}
if(! -d ${GRPDIR}) then
mkdir ${GRPDIR}
endif

#input files
setenv fu13 out.13
setenv fu90 out0.98

setenv fu20 out0.21
setenv fu21 out1.21
setenv fu22 out2.21
setenv fu23 out3.21
setenv fu24 out4.21
setenv fu25 out5.21
setenv fu26 out6.21
setenv fu27 out7.21
setenv fu28 out8.21
setenv fu29 out9.21
setenv fu30 out10.21

setenv fu17 ../field-data.126515t3740_H

## ! binary data big/little endian conversion if needed
setenv  FORT90L -Wl,-T17
#setenv FORT90L -Wl,-T20,-T21,-T22,-T23,-T24,-T25,-T26,-T27,-T28,-T29,-T30


set ID=${DIRL}
#set ID=""

#output files
#setenv fu07 ${GRPDIR}/hat-log
setenv fu07 /dev/null
setenv fu18 ${GRPDIR}/hatten_${ID}.ps
setenv fu70 ${GRPDIR}/coeff_${ID}.out
setenv fu75 ${GRPDIR}/pspectl_${ID}.out
setenv fu77 ${GRPDIR}/qene-av_${ID}.dat
setenv fu78 ${GRPDIR}/marknum_${ID}.dat

setenv fu61 ${GRPDIR}/cntplt_${ID}.dat

#setenv fu70 /dev/null
#setenv fu75 /dev/null
#setenv fu77 /dev/null
#setenv fu78 /dev/null
#
${EXECNAME} << @namelist
 &plotin
   nsttav   =  160001,
   nendav   =  244000,
   nturn    =  8,
   nptime   =  5,
   nsttsp   =  10001,
   nendsp   =  30000,
   omfac    =  2.5e0,
   nevery   =  500,
   nsttpl   =  0,
   nendpl   =  0,
   ifaveq   =  0,
   ifcntplt =  1,
&end
 &stepin
   nstp = 0,30000,60000,90000,120000,150000,180000,210000,244000,
&end
 &collin
   cmag     =  1.00,
   ifbeta   =  0,
&end

@namelist
# atokataduke
gzip -f ${fu18}


###### loop end
end
######

exit
