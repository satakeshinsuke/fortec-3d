#!/bin/csh
#
set FORTRAN = frtpx

set DEBUG=''
set OPTION='-O3 -Kparallel,openmp'

set SRCNAME1=newhatten-h13b.f90

module load GSPS-fx
set LIBNAME=' -lGSPS '
#set LIBNAME=' -L/home/satake/GSPS/GSPS-V4.3.1/lib -lGSPS'

set EXECNAME=gohatten-13b
#
set SRC1=${SRCNAME1}
set EXEC=${EXECNAME}
#
#  Compile
#
${FORTRAN}  ${DEBUG}     ${OPTION}  \
         -o ${EXECNAME}             \
            ${SRCNAME1}             \
            ${LIBNAME}


