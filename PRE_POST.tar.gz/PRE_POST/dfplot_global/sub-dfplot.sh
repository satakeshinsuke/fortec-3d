#!/bin/csh
# ! note ! compile and run on vis1

setenv PARALLEL 8
setenv OMP_NUM_THREADS 8


set EXECNAME=/data/lng/satake/FORTEC-3D_v3-3_final/PRE_POST/dfplot_global/xdfplot

set DATDIR=/data/lng/satake/FORTEC-3D_v3-3_final/SAMPLE/ion-1st+-00_plot

set GRPDIR=${DATDIR}/Graph

set ID=""

cd  ${DATDIR}
if(! -d ${GRPDIR}) then
mkdir ${GRPDIR}
endif

## ! binary data in little endian
setenv FORT90L -Wl,-T8,-T9,-T14,-T30

####output files
#time slice data
setenv fu40 ${GRPDIR}/msg_dflot${ID}.txt
setenv fu41 ${GRPDIR}/dffunc${ID}.dat
setenv fu42 ${GRPDIR}/avewp${ID}.dat
setenv fu43 ${GRPDIR}/wpfld${ID}.dat
setenv fu44 ${GRPDIR}/dffunc2${ID}.dat

#average over entire time slices contained in all data files
setenv fu51 ${GRPDIR}/dffunc${ID}_av.dat
setenv fu52 ${GRPDIR}/avewp${ID}_av.dat
setenv fu53 ${GRPDIR}/wpfld${ID}_av.dat
setenv fu54 ${GRPDIR}/dffunc2${ID}_av.dat

# v-surfaces on which weight-fields to be plotted
# ifave : = 1 both average and time slice, =0 time slice only, =-1 average only
# nfile : number of files to read
# specify file names such as XX of "outXX.08" in kid(i=1,2,...,nfile)
  
${EXECNAME}  << @namelist
&ptin
    ifave=1
    nfile=1
    kid(1)="8"
&end
@namelist
