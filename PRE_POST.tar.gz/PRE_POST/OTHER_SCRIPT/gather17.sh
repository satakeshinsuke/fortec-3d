#!/bin/csh -f

# This script is used for quick health-check of FORTEC-3D simulation (ver.3-3)
# Requires "chk17.gpl" to plot figure

foreach DIRL( case1 case2 )
###########################
cd /work/${DIRL}

cat `ls -v out*.15` >! out15all
cat `ls -v out*.16` >! out16all
cat `ls -v out*.17` >! out17all
cat `ls -v out*.46` >! out46all

#cat `ls -v out*.07` >! out07all
#cat `ls -v out*.27` >! out27all

if(! -d Graph ) then
mkdir Graph
endif

gnuplot ../chk17.gpl

cd ../
############################
end

