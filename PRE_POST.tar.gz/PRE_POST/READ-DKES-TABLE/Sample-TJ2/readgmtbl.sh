#!/bin/csh -f
#

set WKDIR=/home/satake/GSRAKE/READ-DKES-TABLE/Sample-TJ2
set EXEDIR=/home/satake/GSRAKE/READ-DKES-TABLE
set EXECF=xread_gm_tbl

set DATADIR=${WKDIR}
set JOBNAME=tj2-100_44_64_0.0
set ID="_it1"

# note : in this example, field-data file is big-endian
setenv F_UFMTENDIAN 8


#input data
setenv FORT5 ${DATADIR}/input_readgmtbl.dat
setenv FORT8 ${DATADIR}/field-data.${JOBNAME}
setenv FORT9 ${DATADIR}/gamma.${JOBNAME}

#output results
setenv FORT12 ${WKDIR}/ambEr.${JOBNAME}${ID}
setenv FORT15 ${WKDIR}/er-gamma-table.${JOBNAME}${ID}
setenv FORT18 ${WKDIR}/exb-mach_p.${JOBNAME}${ID}
setenv FORT22 ${WKDIR}/ambEr_bad.${JOBNAME}${ID}
#output to fortec
setenv FORT19 ${WKDIR}/gm_table.${JOBNAME}${ID}
#for debug

cd ${WKDIR}


${EXEDIR}/${EXECF} >& ./msg-readgmtbl.${JOBNAME}${ID}

