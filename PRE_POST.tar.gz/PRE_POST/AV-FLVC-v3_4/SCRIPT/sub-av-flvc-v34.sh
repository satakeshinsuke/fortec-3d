#!/bin/csh -f
#PJM -L "rscunit=fx"
#PJM -L "rscgrp=small"
###PJM -L "rscgrp=X24"
#PJM -L "node=1"
#PJM -L "elapse=0:15:00"
#PJM -j
#PJM -g 18243

setenv PARALLEL 16
setenv OMP_NUM_THREADS 16

set EXECNAME=go-avflvc-v3-fx

set NAME=126515t3740_H

#### loop start 
foreach DIRL( +-00 )

set DATDIR=/data/sht/satake/${NAME}/elc-2nd${DIRL}
####
set ID=""

echo ${DATDIR}

set RESDIR=${DATDIR}/Graph

set BFLDDIR=${DATDIR}/../

set GSTBL=/dev/null
set GSTBL=${BFLDDIR}/gm_table.${NAME}
set FLDFILE=${BFLDDIR}/field-data.${NAME}


\cp -f /home/satake/FORTEC3D/NTV/Plotting/AV-FLVC-v3_4/${EXECNAME} ${DATDIR}
cd  ${DATDIR}

if(! -d ${RESDIR}) then
mkdir ${RESDIR}
endif

#input file
setenv fu05 ${BFLDDIR}/input-av-v34.txt
setenv fu12 out.12
setenv fu28 ${FLDFILE}
setenv fu29 ${GSTBL}
setenv fu98 out0.98
## ! binary data in little endian
setenv FORT90L -Wl,-T28,-T29

# note : from v3-4, simulation data file names to be read are specified within the post-process code
#        out*.07 (text) or out*.107 (binary) : E_r and Gamma --> opened as #107
#        out*.27 (text) or out*.108 (binary) : Q, <UB>, dn , dnT --> opened as #108
#        out*.67 (u-d sym) and out*.63 (u-d asym) : NTV --> opened as #67, #63
#        out*.68 (u-d sym) and out*.64 (u-d asym) : NPV --> opened as #68, #64


#output file
setenv fu06 ${RESDIR}/msg-av
setenv fu08 ${RESDIR}/gmvc_tmp.dat
setenv fu09 ${RESDIR}/ergm_tmp.dat
setenv fu10 ${RESDIR}/gmi_tmp.dat
setenv fu11 ${RESDIR}/qvp_tmp.dat
setenv fu17 ${RESDIR}/tvc_tmp.dat
setenv fu18 ${RESDIR}/pvc_tmp.dat
setenv fu19 ${RESDIR}/trq_tmp_vol.dat
setenv fu20 ${RESDIR}/rot_tmp_vol.dat
setenv fu23 ${RESDIR}/tvs_tmp.dat
setenv fu24 ${RESDIR}/pvs_tmp.dat
setenv fu25 ${RESDIR}/tot_visc_tmp.dat
#
setenv fu208 ${RESDIR}/gmvc_ave.dat
setenv fu209 ${RESDIR}/ergm_ave.dat
setenv fu211 ${RESDIR}/qvp_ave.dat
setenv fu217 ${RESDIR}/tvc_ave.dat
setenv fu218 ${RESDIR}/pvc_ave.dat
setenv fu223 ${RESDIR}/tvs_ave.dat
setenv fu224 ${RESDIR}/pvs_ave.dat
setenv fu225 ${RESDIR}/tot_visc_ave.dat
#fitting curve and coefficients
setenv fu309 ${RESDIR}/ergm_fit.dat
setenv fu310 ${RESDIR}/afit.dat
setenv fu311 ${RESDIR}/tvc_fit.dat
setenv fu312 ${RESDIR}/pvc_fit.dat
setenv fu313 ${RESDIR}/tvs_fit.dat
setenv fu314 ${RESDIR}/pvs_fit.dat
# list of mn-mode of NTV, NPV
setenv fu21 ${RESDIR}/visc-mn.dat

#
#  2017/04 MPI parallel reading files (requires nproc=4)
#
#  2017/11 v3-4 : Renewed the post process
#                 Output file names are not specified by environment variables, but are opened inside the code.
#  
#
#mpiexec -stdin ${fu05} -stdout ${fu06} ${DATDIR}/${EXECNAME} 

#serial versoin
${DATDIR}/${EXECNAME} < ${fu05} > ${fu06}


rm -f ${DATDIR}/${EXECNAME}

##### loop end
end
#####


exit

