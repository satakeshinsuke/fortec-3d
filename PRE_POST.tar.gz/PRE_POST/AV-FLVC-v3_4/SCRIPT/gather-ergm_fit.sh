#!/bin/csh -f

# This script is used to make "f3d-{elc,ion}-fit-all.dat" 
# which is used in "fit_result/plot-er-flux-fit.gpl" after running sub-av-flvc-v34.sh
# and sub-find-root.sh

#set ner= nercell in FORTEC-3D

set SPEC=ion

set OUT=fit_result/f3d-${SPEC}-fit-all.dat

echo "" >! ${OUT}

foreach DIRL( +-00 +2.5 -2.5 )

    set FIT=${SPEC}-1st${DIRL}/Graph/ergm_fit.dat
    echo ${FIT}
    cat ${FIT} >> ${OUT}

end

