#!/bin/csh -f

#PJM -L "rscunit=fx"
#PJM -L "rscgrp=small"
#PJM -L "node=1"
#PJM -L "elapse=0:15:00"
#PJM -j
#PJM -g 18243

setenv PARALLEL 16
setenv OMP_NUM_THREADS 16

set EXECNAME=go-findroot-v3

set NAME=126515t3740_H

set ID=""

set DATDIR=/data/lng/satake/FORTEC-3D_v3-3_final/SAMPLE
set RESDIR=${DATDIR}/fit_result

cp -f /data/lng/satake/FORTEC-3D_v3-3_final/PRE_POST/AV-FLVC-v3_4/${EXECNAME} ${DATDIR}
cd  ${DATDIR}

if(! -d ${RESDIR}) then
mkdir ${RESDIR}
endif

#input file
setenv fu08 ${RESDIR}/input_findroot${ID}.dat

#output debug message
setenv fu09 ${RESDIR}/msg-findroot.${NAME}${ID}

#output fittng result
setenv fu100 ${RESDIR}/er-fit-flux.${NAME}${ID}
setenv fu101 ${RESDIR}/amb-flux.${NAME}${ID}

#fortec-3d time average data paths (nspec * nfile)
setenv fu11 elc-1st+-00/Graph/ergm_fit.dat
setenv fu12 elc-1st+2.5/Graph/ergm_fit.dat
setenv fu13 elc-1st-2.5/Graph/ergm_fit.dat

setenv fu21 ion-1st+-00/Graph/ergm_fit.dat 
setenv fu22 ion-1st+2.5/Graph/ergm_fit.dat 
setenv fu23 ion-1st-2.5/Graph/ergm_fit.dat 


#
${DATDIR}/${EXECNAME}

rm -f ${DATDIR}/${EXECNAME}


exit 
